"""Detection Studio chat workflow, isolated from closure QA."""
VERSION = "detection-studio-chat-v2"
