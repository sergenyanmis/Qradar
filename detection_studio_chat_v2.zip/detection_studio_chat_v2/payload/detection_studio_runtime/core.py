"""Catalog grounding, bounded model calls, offline checks and private draft history."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sqlite3
import ssl
import time
from datetime import datetime, timezone
from urllib import request, error
from urllib.parse import urlparse
import uuid

from . import VERSION

MODEL = "qwen3-6-35b-a3b"
PROFILES = {
    "windows_auth": "Windows Security / Kimlik doğrulama",
    "windows_process": "Windows Security / Process creation (4688)",
    "sysmon_discovery": "Windows Sysmon / Process ve davranış",
    "paloalto_globalprotect": "Palo Alto / GlobalProtect VPN",
}
FUNCTIONS = {"UTF8", "QIDNAME", "LOWER", "UPPER", "STR", "LONG", "COALESCE"}
KEYWORDS = {"AND", "OR", "NOT", "IN", "IS", "NULL", "LIKE", "ILIKE", "BETWEEN", "TRUE", "FALSE"}
SCOPE = {
    "windows_auth": "UTF8(payload) ILIKE '%Microsoft-Windows-Security-Auditing%'",
    "windows_process": "UTF8(payload) ILIKE '%Microsoft-Windows-Security-Auditing%'",
    "sysmon_discovery": "UTF8(payload) ILIKE '%Microsoft-Windows-Sysmon%'",
    "paloalto_globalprotect": "UTF8(payload) ILIKE '%|cat=GLOBALPROTECT|%'",
}
CONTRACT = {
    "title": "Kısa kural adı", "intent": "Davranış ve tespit mantığı",
    "telemetry": ["Gerekli log türü / audit önkoşulu"],
    "sigma_yaml": "Tek experimental Sigma YAML kuralı; temsil edilemiyorsa boş string",
    "aql_where": "Sadece filtre ifadesi; örnek: \"Event ID\" = '4688'",
    "projection_fields": ["starttime", "qid"],
    "lookback_minutes": 60,
    "aggregation": None,
    "field_mappings": [{"sigma_field": "EventID", "aql_field": "Event ID", "reason": "Önerilen eşlemenin gerekçesi; kanıt durumu"}],
    "prerequisites": ["Henüz doğrulanması gereken koşullar"],
    "false_positives": ["Somut meşru davranış"], "blind_spots": ["Görünürlük sınırı"],
    "correlation_notes": ["Sıra, zaman penceresi, eşik, CRE farkı"],
}
CONTRACT_NOTE = """
Return ONLY a JSON object with exactly the described keys and types. Do not use Markdown fences.
All prose values must be Turkish. Use empty arrays when nothing applies.
aggregation may be null or {"group_by": [exact catalog fields], "record_count_min": integer >= 2}.
projection_fields must be a nonempty array of exact catalog field names.
aql_where must be nonempty. Missing evidence is a prerequisite, never a fabricated validation.
"""


class StudioError(Exception):
    """User-safe error, never containing a token or raw HTTP response."""


class NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # Do not forward an Authorization header to a redirected endpoint.
        return None


def digest(value):
    return hashlib.sha256(value).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def load_environment(root):
    studio = Path(root) / "detection_studio"
    try:
        raw = (studio / "catalog/catalog.json").read_bytes()
        catalog = json.loads(raw)
        profile = json.loads((studio / "environment_profile.json").read_text(encoding="utf-8"))
        if profile["catalog_sha256"] != digest(raw):
            raise StudioError("Profil ve katalog farklı snapshot kullanıyor. Profili yeniden oluşturun.")
        fields = {item["name"]: item for item in catalog["datasets"]["event_fields"]["items"]}
        sources = {int(item["id"]): item for item in catalog["datasets"]["log_sources"]["items"]}
    except StudioError:
        raise
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise StudioError("Katalog/profil okunamadı. Önce build_detection_studio_profile_v1.py --root ile ortam profilini oluşturun.") from exc
    if not fields or not sources:
        raise StudioError("Katalogda event alanı veya log source yok.")
    return {"catalog": catalog, "profile": profile, "fields": fields, "sources": sources,
            "catalog_sha256": digest(raw), "profile_sha256": digest(canonical(profile).encode())}


def sources_for(env, profile):
    if profile == "paloalto_globalprotect":
        ids = {int(row["log_source_id"]) for row in env["profile"]["paloalto_globalprotect"]["validated_sample_mappings"]}
    else:
        ids = {int(row["log_source_id"]) for row in env["profile"]["windows_observations"] if row["profile"] == profile}
    return {sid: env["sources"][sid] for sid in sorted(ids) if sid in env["sources"] and env["sources"][sid].get("enabled", True)}


def grounding(env, profile, source_ids, extra_fields=()):
    if profile not in PROFILES:
        raise StudioError("Bilinmeyen telemetri profili.")
    allowed = sources_for(env, profile)
    ids = sorted(set(source_ids))
    if not 1 <= len(ids) <= 8 or any(type(sid) is not int or sid not in allowed for sid in ids):
        raise StudioError("Bu profil için katalogdan 1–8 gözlemlenmiş log source seçin.")
    if len(extra_fields) > 20 or any(field not in env["fields"] for field in extra_fields):
        raise StudioError("Ek alanlar katalogdan seçilmelidir (en fazla 20).")
    observations = [row for row in env["profile"]["windows_observations"]
                    if row["profile"] == profile and row["log_source_id"] in ids]
    mappings = [row for row in env["profile"]["paloalto_globalprotect"]["validated_sample_mappings"]
                if row["log_source_id"] in ids] if profile == "paloalto_globalprotect" else []
    field_names = {"starttime", "logsourceid", "devicetype", "qid", "username", "sourceip", "destinationip", "payload", "eventcount"}
    field_names.update(extra_fields)
    for row in observations:
        field_names.update(row["fields"])
    field_names.update(row["aql_field"] for row in mappings)
    fields = {name: {"type": env["fields"][name].get("object_value_type"), "state": "catalog_only"}
              for name in sorted(field_names) if name in env["fields"]}
    context = {"profile": profile, "selected_sources": [{"id": sid, "name": allowed[sid]["name"]} for sid in ids],
               "catalog_sha256": env["catalog_sha256"], "profile_sha256": env["profile_sha256"],
               "fields": fields, "population_observations": observations, "same_row_sample_mappings": mappings,
               "mandatory_scope_predicate": SCOPE[profile], "expression_function_allowlist": sorted(FUNCTIONS)}
    if profile == "paloalto_globalprotect":
        context["constraints"] = env["profile"]["paloalto_globalprotect"]["constraints"]
        context["identity_state"] = env["profile"]["paloalto_globalprotect"]["identity_state"]
    else:
        context["constraints"] = ["Field population is not a provider/Event-ID-specific semantic validation.",
                                  "The host adds a provider marker guard; representation still needs a live test."]
    if len(canonical(context)) > 65000:
        raise StudioError("Seçilen alan bağlamı çok büyük; log source veya ek alan sayısını azaltın.")
    return context


def system_prompt():
    skill = (Path(__file__).parent / "skills/detection-engineering/SKILL.md").read_text(encoding="utf-8")
    return skill + "\n" + CONTRACT_NOTE + "\nJSON contract:\n" + canonical(CONTRACT)


def model_settings(root):
    # Load the existing trusted configuration; never import the gateway or initialize QA.
    secrets = None
    environment_token = os.getenv("HEIMDALL_TOKEN") or ""
    path = Path(root) / "qradar_secrets.py"
    if not environment_token.strip() and path.is_file():
        try:
            spec = importlib.util.spec_from_file_location("_studio_local_secrets", path)
            secrets = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(secrets)
        except Exception as exc:
            raise StudioError("qradar_secrets.py yüklenemedi; yapılandırma dosyasını kontrol edin.") from exc
    token = (environment_token or getattr(secrets, "HEIMDALL_TOKEN", "") or "").strip()
    url = (os.getenv("SOC_DETECTION_HEIMDALL_CHAT_URL") or
           "https://heimdall-uat.tombank.com.tr/v1/chat/completions").strip()
    parsed = urlparse(url)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise StudioError("Detection Studio Heimdall adresi geçerli bir HTTPS URL olmalıdır.")
    if not token:
        raise StudioError("HEIMDALL_TOKEN ortam değişkeninde veya qradar_secrets.py içinde bulunamadı.")
    return url, token


def parse_json_completion(body):
    try:
        choice = body["choices"][0]
        if choice.get("finish_reason") != "stop":
            raise StudioError("Model yanıtı tamamlanmadı. Girdiyi kısaltıp yeniden deneyin; yarım taslak kaydedilmedi.")
        content = choice["message"]["content"]
        if not isinstance(content, str) or len(content) > 100000:
            raise ValueError("content")
        content = re.sub(r"<think>.*?</think>", "", content, flags=re.S).strip()
        if content.startswith("```"):
            content = re.sub(r"\A```(?:json)?\s*|\s*```\Z", "", content).strip()
        result = json.loads(content)
    except StudioError:
        raise
    except (KeyError, IndexError, TypeError, ValueError) as exc:
        raise StudioError("Model beklenen JSON yanıtını üretmedi; taslak kaydedilmedi.") from exc
    if not isinstance(result, dict):
        raise StudioError("Model JSON nesnesi döndürmedi.")
    return result


def parse_completion(body):
    result = parse_json_completion(body)
    validate_contract(result)
    return result


def validate_contract(data):
    if not isinstance(data, dict) or set(data) != set(CONTRACT):
        raise StudioError("Model yanıtının alanları JSON sözleşmesiyle uyuşmuyor.")
    for key in ("title", "intent", "sigma_yaml", "aql_where"):
        if not isinstance(data[key], str) or len(data[key]) > 30000:
            raise StudioError("Model yanıtında geçersiz metin alanı: " + key)
    if not data["title"].strip() or not data["aql_where"].strip():
        raise StudioError("Kural adı ve AQL filtresi boş olamaz.")
    for key in ("telemetry", "projection_fields", "prerequisites", "false_positives", "blind_spots", "correlation_notes"):
        if not isinstance(data[key], list) or len(data[key]) > 40 or any(not isinstance(v, str) or len(v) > 5000 for v in data[key]):
            raise StudioError("Model yanıtında geçersiz liste: " + key)
    minutes = data["lookback_minutes"]
    if type(minutes) is not int or not 1 <= minutes <= 1440:
        raise StudioError("Taslak sorgu penceresi 1–1440 dakika olmalıdır.")
    mappings = data["field_mappings"]
    if not isinstance(mappings, list) or len(mappings) > 40 or any(
        not isinstance(row, dict) or set(row) != {"sigma_field", "aql_field", "reason"} or
        any(not isinstance(v, str) or len(v) > 5000 for v in row.values()) for row in mappings
    ):
        raise StudioError("Model alan eşleme tablosu geçersiz.")


def request_draft(root, context, scenario, input_kind="scenario", previous=None, revision="", opener=None):
    if input_kind not in {"scenario", "code"} or not isinstance(scenario, str) or not 10 <= len(scenario.strip()) <= 16000:
        raise StudioError("Senaryo/kod 10–16000 karakter olmalıdır.")
    if len(revision) > 4000:
        raise StudioError("Revizyon isteği en fazla 4000 karakter olabilir.")
    prompt = system_prompt()
    message = {"environment": context, "input_kind": input_kind, "input": scenario, "revision_instruction": revision}
    if previous:
        message["previous_draft"] = previous
    result, metadata = request_json(root, prompt, message, opener=opener)
    validate_contract(result)
    return result, metadata


def request_json(root, prompt, message, max_tokens=6000, opener=None):
    """Shared bounded HTTPS transport for planning and detection generation."""
    url, token = model_settings(root)
    body = {"model": MODEL, "messages": [{"role": "system", "content": prompt},
            {"role": "user", "content": canonical(message)}], "temperature": 0,
            "max_tokens": max_tokens, "stream": False, "chat_template_kwargs": {"enable_thinking": False}}
    if len(canonical(body)) > 160000:
        raise StudioError("İstek boyutu sınırı aşıldı. Girdiyi veya revizyonu kısaltın.")
    req = request.Request(url, data=canonical(body).encode("utf-8"), method="POST",
                          headers={"Authorization": "Bearer " + token, "X-Provider": "vllm", "Content-Type": "application/json"})
    started = time.monotonic()
    try:
        if opener is None:
            ca = os.getenv("SOC_DETECTION_HEIMDALL_CA_BUNDLE") or None
            opener = request.build_opener(NoRedirect(), request.HTTPSHandler(context=ssl.create_default_context(cafile=ca))).open
        with opener(req, timeout=180) as response:
            raw = response.read(1000001)
        if len(raw) > 1000000:
            raise StudioError("Model yanıtı boyut sınırını aştı.")
        result = parse_json_completion(json.loads(raw))
    except error.HTTPError as exc:
        raise StudioError("Heimdall HTTP " + str(exc.code) + ". Taslak kaydedilmedi.") from None
    except (error.URLError, TimeoutError, OSError, ValueError) as exc:
        raise StudioError("Heimdall isteği tamamlanamadı (" + type(exc).__name__ + ").") from None
    return result, {"model": MODEL, "duration_sec": round(time.monotonic() - started, 2),
                    "prompt_sha256": digest(prompt.encode()), "usage": "not_collected"}


def quote_field(name):
    if not isinstance(name, str) or not name or any(ch in name for ch in '"\r\n\x00'):
        raise StudioError("AQL alan adı güvenli biçimde temsil edilemiyor.")
    return name if re.fullmatch(r"[a-z][a-z0-9_]*", name) else '"' + name + '"'


def predicate_fields(expression, allowed):
    """Restricted lexical checks only. This is intentionally NOT an AQL grammar validator."""
    token = re.compile(r"\s+|'(?:[^']|'')*'|\"[^\"\r\n]+\"|[A-Za-z_][A-Za-z0-9_]*|\d+(?:\.\d+)?|<=|>=|!=|<>|[=<>(),.+*/%!-]")
    tokens, cursor = [], 0
    while cursor < len(expression):
        match = token.match(expression, cursor)
        if not match:
            raise StudioError("AQL filtresinde desteklenmeyen karakter veya tamamlanmamış string var.")
        value = match.group()
        cursor = match.end()
        if not value.isspace():
            tokens.append(value)
    if not tokens or len(tokens) > 1000:
        raise StudioError("AQL filtresi boş veya çok büyük.")
    fields, depth = set(), 0
    for i, value in enumerate(tokens):
        if value.startswith("'"):
            continue
        if value == "(":
            depth += 1
        elif value == ")":
            depth -= 1
            if depth < 0:
                raise StudioError("AQL parantezleri eşleşmiyor.")
        elif value.startswith('"'):
            name = value[1:-1]
            if name not in allowed:
                raise StudioError("Katalog bağlamında olmayan AQL alanı: " + name)
            fields.add(name)
        elif re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value):
            if value.upper() in KEYWORDS:
                continue
            if i + 1 < len(tokens) and tokens[i + 1] == "(":
                if value.upper() not in FUNCTIONS:
                    raise StudioError("Desteklenmeyen AQL fonksiyonu/ifadesi: " + value)
            elif value.upper() not in KEYWORDS:
                if value not in allowed:
                    raise StudioError("Katalog bağlamında olmayan AQL alanı/ifade: " + value)
                fields.add(value)
    if depth:
        raise StudioError("AQL parantezleri eşleşmiyor.")
    if "--" in expression or "/*" in expression or "*/" in expression:
        raise StudioError("AQL filtresinde yorum kullanmayın.")
    return fields


def compile_aql(data, context):
    allowed = context["fields"]
    used = predicate_fields(data["aql_where"], allowed)
    projection = data["projection_fields"]
    if not 1 <= len(projection) <= 20 or len(projection) != len(set(projection)) or any(f not in allowed for f in projection):
        raise StudioError("AQL projection alanları seçilen katalog bağlamıyla uyuşmuyor.")
    used.update(projection)
    aggregate = data["aggregation"]
    if aggregate is None:
        select = ", ".join(quote_field(f) for f in projection)
        tail = ""
    else:
        if not isinstance(aggregate, dict) or set(aggregate) != {"group_by", "record_count_min"}:
            raise StudioError("AQL aggregation sözleşmesi geçersiz.")
        group = aggregate["group_by"]
        minimum = aggregate["record_count_min"]
        if (not isinstance(group, list) or not 1 <= len(group) <= 4 or any(not isinstance(f, str) or f not in allowed for f in group)
                or len(group) != len(set(group)) or type(minimum) is not int or not 2 <= minimum <= 1000000):
            raise StudioError("AQL gruplama alanları veya kayıt eşiği geçersiz.")
        used.update(group)
        group_sql = ", ".join(quote_field(f) for f in group)
        select = group_sql + ", COUNT(*) AS 'matched_records'"
        tail = f" GROUP BY {group_sql} HAVING COUNT(*) >= {minimum}"
    ids = ", ".join(str(s["id"]) for s in context["selected_sources"])
    aql = (f"SELECT {select} FROM events WHERE (logsourceid IN ({ids})) AND "
           f"({context['mandatory_scope_predicate']}) AND ({data['aql_where']}){tail} "
           f"LIMIT 100 LAST {data['lookback_minutes']} MINUTES")
    return aql, sorted(used)


def validate_sigma(text):
    if not text.strip():
        return {"status": "not_generated", "errors": [], "fields": []}
    try:
        import yaml
        class UniqueLoader(yaml.SafeLoader):
            pass
        def unique_mapping(loader, node, deep=False):
            result = {}
            for key_node, val_node in node.value:
                key = loader.construct_object(key_node, deep=deep)
                if key in result:
                    raise ValueError("Duplicate YAML key")
                result[key] = loader.construct_object(val_node, deep=deep)
            return result
        UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, unique_mapping)
        documents = list(yaml.load_all(text, Loader=UniqueLoader))
        if len(documents) != 1 or not isinstance(documents[0], dict):
            raise ValueError("Exactly one event rule required")
        rule = documents[0]
        if not all(key in rule for key in ("title", "id", "status", "logsource", "detection", "level")):
            raise ValueError("Missing required rule metadata")
        uuid.UUID(str(rule["id"]))
        if rule["status"] != "experimental" or not isinstance(rule["logsource"], dict) or not rule["logsource"]:
            raise ValueError("Experimental status and logsource required")
        detection = rule["detection"]
        if not isinstance(detection, dict) or not detection.get("condition"):
            raise ValueError("Missing condition")
        fields = set()
        def collect(selection):
            if isinstance(selection, dict):
                for key in selection:
                    fields.add(str(key).split("|")[0])
            elif isinstance(selection, list):
                for item in selection:
                    collect(item)
        for key, selection in detection.items():
            if key not in {"condition", "timeframe"}:
                collect(selection)
        try:
            from sigma.collection import SigmaCollection
        except ImportError:
            return {"status": "yaml_checked_pysigma_missing", "errors": [], "fields": sorted(fields)}
        collection = SigmaCollection.from_yaml(text, collect_errors=False)
        if len(collection.rules) != 1:
            raise ValueError("Exactly one event rule required")
        return {"status": "pysigma_parsed", "errors": [], "fields": sorted(fields)}
    except ImportError:
        return {"status": "dependency_missing", "errors": ["PyYAML kurulu değil."], "fields": []}
    except Exception as exc:
        return {"status": "invalid", "errors": ["Sigma doğrulaması başarısız: " + type(exc).__name__], "fields": []}


def audit_draft(data, context):
    validate_contract(data)
    errors = []
    try:
        aql, used = compile_aql(data, context)
        aql_status = "offline_lexical_checks_passed"
    except StudioError as exc:
        aql, used, aql_status = "", [], "blocked"
        errors.append(str(exc))
    sigma = validate_sigma(data["sigma_yaml"])
    errors.extend(sigma["errors"])
    mapped = {}
    for row in data["field_mappings"]:
        name = row["sigma_field"]
        if name in mapped:
            errors.append("Tekrarlanan Sigma alan eşlemesi: " + name)
        mapped[name] = row["aql_field"]
        if row["aql_field"] not in context["fields"]:
            errors.append("Çözümlenmemiş/katalog dışı eşleme: " + name)
    for name in sigma["fields"]:
        if name not in mapped:
            errors.append("Sigma alanı için QRadar eşleme önerisi yok: " + name)
    evidence = []
    for field in sorted(set(used) | {f for f in mapped.values() if f in context["fields"]}):
        for source in context["selected_sources"]:
            sid = source["id"]
            matches = [r for r in context["same_row_sample_mappings"] if r["log_source_id"] == sid and r["aql_field"] == field]
            pop = [r for r in context["population_observations"] if r["log_source_id"] == sid and field in r["fields"]]
            state = "sample_matched_scoped" if matches else "population_only" if pop else "catalog_only"
            evidence.append({"log_source_id": sid, "field": field, "evidence": state})
    return {"state": "blocked" if errors else "draft_needs_validation", "errors": errors,
            "aql": aql, "aql_check": aql_status, "aql_syntax": "not_tested_on_qradar",
            "sigma": sigma, "field_evidence": evidence,
            "live_search": "not_run", "sigma_aql_equivalence": "not_verified", "deployment": "not_deployed",
            "prerequisites": data["prerequisites"] + context.get("constraints", [])}


def history_connection(root):
    folder = Path(root) / "detection_studio" / "drafts"
    folder.mkdir(parents=True, exist_ok=True, mode=0o700)
    path = folder / "studio.sqlite3"
    # Create with private mode before sqlite opens it (no initial world-readable window).
    fd = os.open(path, os.O_CREAT | os.O_RDWR, 0o600)
    os.close(fd)
    os.chmod(path, 0o600)
    conn = sqlite3.connect(path, timeout=15)
    conn.row_factory = sqlite3.Row
    conn.execute("""CREATE TABLE IF NOT EXISTS drafts (
        id TEXT PRIMARY KEY, owner TEXT NOT NULL, series_id TEXT NOT NULL,
        revision INTEGER NOT NULL, parent_id TEXT, created_at_utc TEXT NOT NULL,
        input_sha256 TEXT NOT NULL, document TEXT NOT NULL,
        UNIQUE(owner, series_id, revision))""")
    conn.execute("CREATE INDEX IF NOT EXISTS drafts_owner_time ON drafts(owner, created_at_utc)")
    conn.commit()
    return conn


def save_draft(root, owner, scenario, input_kind, context, data, audit, metadata, parent_id=None, *, after_insert=None):
    if not owner or not isinstance(owner, str):
        raise StudioError("Taslak için doğrulanmış kullanıcı kimliği gerekli.")
    with history_connection(root) as conn:
        conn.execute("BEGIN IMMEDIATE")
        series, revision = uuid.uuid4().hex, 1
        if parent_id:
            parent = conn.execute("SELECT * FROM drafts WHERE id=? AND owner=?", (parent_id, owner)).fetchone()
            if parent is None:
                raise StudioError("Revize edilecek taslak bu kullanıcıya ait değil.")
            series = parent["series_id"]
            revision = conn.execute("SELECT MAX(revision) FROM drafts WHERE owner=? AND series_id=?", (owner, series)).fetchone()[0] + 1
        rowid, created = uuid.uuid4().hex, datetime.now(timezone.utc).isoformat()
        record = {"id": rowid, "version": VERSION, "series_id": series, "revision": revision,
                  "parent_id": parent_id, "created_at_utc": created, "scenario": scenario,
                  "input_kind": input_kind, "context": context, "draft": data, "validation": audit, "metadata": metadata}
        fingerprint = digest(canonical({"input": scenario, "kind": input_kind, "context": context}).encode())
        record["input_sha256"] = fingerprint
        conn.execute("INSERT INTO drafts VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                     (rowid, owner, series, revision, parent_id, created, fingerprint, canonical(record)))
        if after_insert is not None:
            after_insert(conn, record)
    conn.close()
    return record


def list_drafts(root, owner):
    with history_connection(root) as conn:
        rows = conn.execute("SELECT id, created_at_utc, revision, series_id, document FROM drafts WHERE owner=? ORDER BY created_at_utc DESC LIMIT 50", (owner,)).fetchall()
    conn.close()
    return [{"id": row["id"], "created_at_utc": row["created_at_utc"], "revision": row["revision"],
             "title": json.loads(row["document"])["draft"]["title"]} for row in rows]


def get_draft(root, owner, draft_id):
    with history_connection(root) as conn:
        row = conn.execute("SELECT document FROM drafts WHERE owner=? AND id=?", (owner, draft_id)).fetchone()
    conn.close()
    return json.loads(row["document"]) if row else None
