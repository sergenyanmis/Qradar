"""Local synthetic preview / AppTest fixture. Never deployed by the installer."""
import os
from pathlib import Path
import sys
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "payload"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from test_studio import draft, fixture_environment
from detection_studio_runtime import core, chat
from detection_studio_ui import render_detection_studio

st.set_page_config(page_title="Detection Studio · test", layout="wide")
root = Path(os.environ["STUDIO_UI_TEST_ROOT"])
if not (root / "detection_studio/catalog/catalog.json").exists():
    fixture_environment(root)


def plan(*args, **kwargs):
    return {"action": "generate", "profile": "windows_process", "source_ids": [18127], "extra_fields": [],
            "reason": "4688 process creation için örneklemde Command alanı gözlenen kaynak seçildi. Kapsam yalnız bu gözlenen kaynaktır.",
            "clarification": ""}, {"model": core.MODEL, "duration_sec": 0}


chat.request_plan = plan
core.request_draft = lambda *a, **k: (draft(), {"model": core.MODEL, "duration_sec": 0})
render_detection_studio(root, lambda: None,
                        lambda: {"username": os.getenv("STUDIO_UI_TEST_USER", "unit-user"),
                                 "role": os.getenv("STUDIO_UI_TEST_ROLE", "L1")})
