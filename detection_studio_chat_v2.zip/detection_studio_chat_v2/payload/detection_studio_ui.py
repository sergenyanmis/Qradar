"""Conversation-first Detection Studio with a scoped, real-time workflow panel."""
import html
import json
from pathlib import Path

from detection_studio_runtime import core, chat

CSS = """<style>
.st-key-ds_chat_workspace {--ds-line:rgba(120,157,203,.20);--ds-muted:#91a7c1;}
.st-key-ds_chat_workspace .ds-eyebrow {color:#62d9d0;font-size:11px;letter-spacing:2px;font-weight:700;}
.st-key-ds_chat_workspace .ds-title {font-size:29px;font-weight:730;letter-spacing:-.8px;line-height:1.3;margin:7px 0;}
.st-key-ds_chat_workspace .ds-sub {color:var(--ds-muted);font-size:13px;line-height:1.7;}
.st-key-ds_chat_workspace .ds-hero {padding:20px 24px;border:1px solid var(--ds-line);border-radius:18px;
 background:radial-gradient(ellipse at top right,rgba(25,167,176,.12),transparent 60%),#091525;margin-bottom:18px;}
.st-key-ds_chat_workspace .ds-pill {display:inline-block;border:1px solid var(--ds-line);border-radius:20px;
 padding:4px 9px;font-size:11px;color:#a9bfd8;margin:8px 6px 0 0;}
.st-key-ds_chat_workspace .ds-flow {background:#091525;border:1px solid var(--ds-line);border-radius:17px;padding:20px;}
.st-key-ds_chat_workspace .ds-flow-title {font-size:15px;font-weight:700;color:#e8f1ff;margin-bottom:5px;}
.st-key-ds_chat_workspace .ds-flow-sub {font-size:11px;color:var(--ds-muted);line-height:1.6;margin-bottom:18px;}
.st-key-ds_chat_workspace .ds-step {display:flex;gap:11px;padding:0 0 19px;position:relative;}
.st-key-ds_chat_workspace .ds-step:last-child {padding-bottom:0;}
.st-key-ds_chat_workspace .ds-step:not(:last-child):before {content:'';position:absolute;left:12px;top:28px;bottom:4px;
 border-left:1px solid var(--ds-line);}
.st-key-ds_chat_workspace .ds-dot {width:26px;height:26px;flex:0 0 26px;border-radius:50%;display:flex;align-items:center;
 justify-content:center;background:#101f33;border:1px solid #263c55;color:#6c839f;font-size:12px;}
.st-key-ds_chat_workspace .ds-step.complete .ds-dot {background:#10312f;border-color:#27665f;color:#68dfc4;}
.st-key-ds_chat_workspace .ds-step.running .ds-dot {border-color:#45c6dc;color:#89e8ef;animation:dsPulse 1.4s infinite;}
.st-key-ds_chat_workspace .ds-step.error .ds-dot {color:#ff9a9a;border-color:#8b4552;}
.st-key-ds_chat_workspace .ds-step.waiting .ds-dot,.st-key-ds_chat_workspace .ds-step.needs_revision .ds-dot {color:#f0c16e;border-color:#806433;}
.st-key-ds_chat_workspace .ds-step.skipped {opacity:.45;}
.st-key-ds_chat_workspace .ds-step-name {font-size:12px;color:#dce8fa;font-weight:650;line-height:1.4;}
.st-key-ds_chat_workspace .ds-step-detail {font-size:11px;color:var(--ds-muted);line-height:1.65;margin-top:3px;overflow-wrap:anywhere;}
.st-key-ds_chat_workspace .ds-time {color:#67c6c3;font-size:10px;margin-left:6px;white-space:nowrap;}
.st-key-ds_chat_workspace .ds-empty {padding:35px 8px 20px;}
.st-key-ds_chat_workspace .ds-empty h3 {font-size:22px;letter-spacing:-.5px;margin-bottom:12px;}
.st-key-ds_chat_workspace .ds-empty p {color:var(--ds-muted);font-size:14px;line-height:1.9;}
.st-key-ds_chat_workspace [data-testid="stChatMessage"] {border:1px solid var(--ds-line);border-radius:15px;}
.st-key-ds_chat_workspace .ds-result-label {font-size:11px;color:#68dfc4;letter-spacing:1px;}
@keyframes dsPulse {50%{box-shadow:0 0 0 5px rgba(69,198,220,.1);}}
@media (prefers-reduced-motion:reduce) {.st-key-ds_chat_workspace .ds-dot {animation:none!important;}}
</style>"""


def flow_html(events=None):
    rows = events or [{"title": title, "detail": detail, "state": "pending", "duration_sec": None}
                      for _, title, detail in chat.STAGES]
    symbols = {"complete": "✓", "running": "●", "pending": "·", "error": "!", "waiting": "?", "needs_revision": "!", "skipped": "–"}
    parts = ['<div class="ds-flow"><div class="ds-flow-title">İşlem akışı</div>',
             '<div class="ds-flow-sub">Gerçek işlem durumları · Qwen / Heimdall<br>QRadar canlı testi bu sürümde çalıştırılmaz.</div>']
    for row in rows:
        state = row["state"] if row["state"] in symbols else "pending"
        duration = row.get("duration_sec")
        stamp = '' if duration is None else f'<span class="ds-time">{float(duration):.1f} sn</span>'
        parts.append(f'<div class="ds-step {state}"><div class="ds-dot">{symbols[state]}</div><div>'
                     f'<div class="ds-step-name">{html.escape(row["title"])}{stamp}</div>'
                     f'<div class="ds-step-detail">{html.escape(row["detail"])}</div></div></div>')
    return ''.join(parts) + '</div>'


def _points(st, title, values):
    if values:
        st.markdown("**" + title + "**")
        for value in values:
            st.write("• " + str(value))


def _render_record(st, record):
    data, validation = record["draft"], record["validation"]
    st.caption(f"v{record['revision']} · {record['metadata']['model']} · {record['created_at_utc'][:19]}")
    if validation["errors"]:
        st.warning("Bu taslak düzeltme gerektiriyor. Hatalar Kontroller sekmesinde.")
    tabs = st.tabs(["Tespit mantığı", "Sigma", "AQL", "Alan kanıtları", "Kontroller"])
    with tabs[0]:
        st.write(data["intent"])
        _points(st, "Telemetri", data["telemetry"])
        _points(st, "Önkoşullar", data["prerequisites"])
        _points(st, "False positive / tuning", data["false_positives"])
        _points(st, "Kör noktalar", data["blind_spots"])
        _points(st, "Korelasyon sınırları", data["correlation_notes"])
    with tabs[1]:
        if data["sigma_yaml"]:
            st.code(data["sigma_yaml"], language="yaml")
            st.download_button("Sigma indir", data["sigma_yaml"], "sigma_draft.yml", "text/yaml", key="ds_sigma_" + record["id"])
        else:
            st.info("Davranış tek event Sigma kuralıyla temsil edilemiyor; önkoşulları ve korelasyon sınırlarını incele.")
        st.caption("Sigma kontrolü: " + validation["sigma"]["status"])
    with tabs[2]:
        if validation["aql"]:
            st.code(validation["aql"], language="sql")
            st.download_button("AQL indir", validation["aql"], "query_draft.aql", "text/plain", key="ds_aql_" + record["id"])
        else:
            st.warning("AQL yerel kontrolleri geçemedi.")
            st.code(data["aql_where"], language="sql")
        st.caption("Kaynak ve provider/category kapsamı otomatik eklendi. Canlı QRadar testi yapılmadı.")
        if data["aggregation"]:
            st.caption("COUNT(*) saklanan kayıtları sayar; coalescing varsa özgün olay toplamı olmayabilir.")
    with tabs[3]:
        if data["field_mappings"]:
            st.dataframe(data["field_mappings"], use_container_width=True, hide_index=True)
        if validation["field_evidence"]:
            st.dataframe(validation["field_evidence"], use_container_width=True, hide_index=True)
        st.caption("catalog_only: tanımlı · population_only: örneklemde dolu · sample_matched_scoped: kaynak/format örnekleminde eşleşti")
    with tabs[4]:
        for message in validation["errors"]:
            st.warning(message)
        st.json({key: validation[key] for key in ("state", "aql_check", "aql_syntax", "live_search", "sigma_aql_equivalence", "deployment")})
        _points(st, "Ortam sınırları", validation["prerequisites"])
        with st.expander("Katalog ve otomatik seçim ayrıntıları"):
            st.json(record["context"])
    st.download_button("Sürüm raporu indir", json.dumps(record, ensure_ascii=False, indent=2),
                       "detection_draft_" + record["id"][:8] + ".json", "application/json", key="ds_json_" + record["id"])


def _render_messages(st, root, owner, messages):
    last_draft = max((i for i, m in enumerate(messages) if m.get("draft_id")), default=-1)
    for i, message in enumerate(messages):
        with st.chat_message(message["role"]):
            # User and model text are never interpolated into unsafe HTML.
            st.markdown(message["content"])
            if message.get("draft_id"):
                record = core.get_draft(root, owner, message["draft_id"])
                if record:
                    with st.expander(f"v{record['revision']} · {record['draft']['title']}", expanded=i == last_draft):
                        _render_record(st, record)


def render_detection_studio(root, require_role, current_user):
    import streamlit as st

    root = Path(root)
    require_role()
    user = current_user()
    if not user or not user.get("username"):
        st.error("Kullanıcı kimliği doğrulanamadı.")
        return
    owner = str(user["username"])
    if st.session_state.get("ds_owner") != owner:
        for key in list(st.session_state):
            if key.startswith("ds_"):
                del st.session_state[key]
        st.session_state["ds_owner"] = owner

    def authorize():
        require_role()
        fresh = current_user()
        if not fresh or str(fresh.get("username")) != owner or fresh.get("role") not in {"L1", "L2", "L3", "admin"}:
            raise core.StudioError("Üretim yetkisi doğrulanamadı. Oturumunu yenile.")

    try:
        threads = chat.list_chats(root, owner)
        legacy = core.list_drafts(root, owner)
    except Exception:
        st.error("Studio geçmişi açılamadı. Servis kullanıcısının detection_studio/drafts dizini izinlerini kontrol edin.")
        return
    thread, messages = None, []
    active_id = st.session_state.get("ds_chat_active")
    if active_id:
        try:
            thread, messages = chat.read_chat(root, owner, active_id)
        except core.StudioError:
            st.session_state.pop("ds_chat_active", None)

    with st.container(key="ds_chat_workspace"):
        st.markdown(CSS, unsafe_allow_html=True)
        header, action = st.columns([5, 1], vertical_alignment="center")
        with header:
            st.markdown('<div class="ds-eyebrow">DETECTION ENGINEERING WORKSPACE</div><div class="ds-title">Detection Studio</div>', unsafe_allow_html=True)
        with action:
            if st.button("＋ Yeni sohbet", key="ds_new_chat", use_container_width=True):
                st.session_state.pop("ds_chat_active", None)
                st.rerun()
        st.markdown('<div class="ds-hero"><div class="ds-sub">Tespit etmek istediğin davranışı anlat veya kodu paylaş. '
                    'Kaynakları ve alanları ortam kanıtlarından belirleyeyim; Sigma ve AQL taslaklarını birlikte geliştirelim.</div>'
                    '<span class="ds-pill">Otomatik ortam seçimi</span><span class="ds-pill">Sürümlü taslaklar</span>'
                    '<span class="ds-pill">Sigma + QRadar AQL</span></div>', unsafe_allow_html=True)
        left, right = st.columns([2.35, 1], gap="large")
        with right:
            panel = st.empty()
            events = next((m["metadata"]["events"] for m in reversed(messages) if m["metadata"].get("events")), None)
            panel.markdown(flow_html(events), unsafe_allow_html=True)
            if thread and thread["last_draft_id"]:
                record = core.get_draft(root, owner, thread["last_draft_id"])
                if record:
                    with st.expander("Otomatik belirlenen ortam", expanded=True):
                        st.caption(core.PROFILES.get(record["context"]["profile"], record["context"]["profile"]))
                        for source in record["context"]["selected_sources"]:
                            st.write(f"{source['name']} · #{source['id']}")
                        st.caption(f"{len(record['context']['fields'])} alan · yalnız seçilen gözlenmiş kaynaklar")
                        reason = record["context"].get("automatic_selection", {}).get("reason")
                        if reason:
                            st.caption(reason)
            with st.expander("Sohbetlerim", expanded=False):
                if threads:
                    lookup = {row["id"]: row for row in threads}
                    ids = list(lookup)
                    selected = st.selectbox("Son sohbetler", ids, index=ids.index(active_id) if active_id in ids else 0,
                                            format_func=lambda cid: lookup[cid]["title"], key="ds_history_chat")
                    if st.button("Sohbeti aç", key="ds_open_chat"):
                        st.session_state["ds_chat_active"] = selected
                        st.rerun()
                else:
                    st.caption("İlk mesajından sonra sohbet burada saklanacak.")
                if legacy:
                    by_id = {row["id"]: row for row in legacy}
                    selected = st.selectbox("Taslak sürümleri", list(by_id),
                        format_func=lambda rid: f"v{by_id[rid]['revision']} · {by_id[rid]['title']}", key="ds_legacy_draft")
                    if st.button("Taslakla sohbet başlat", key="ds_import_draft", disabled=user.get("role") not in {"L1", "L2", "L3", "admin"}):
                        authorize()
                        st.session_state["ds_chat_active"] = chat.import_draft(root, owner, selected)
                        st.rerun()
        with left:
            with st.container(height=610, border=True, key="ds_conversation"):
                if not messages:
                    st.markdown('<div class="ds-empty"><div class="ds-eyebrow">BİRLİKTE BİR DETECTION OLUŞTURALIM</div>'
                                '<h3>Hangi davranışı yakalamak istiyorsun?</h3><p>Senaryo, komut veya kodla başlayabilirsin. '
                                'Kaynak ve alan seçmene gerek yok.<br>Eksik telemetri varsa konuşarak netleştiririz.</p></div>', unsafe_allow_html=True)
                    with st.chat_message("assistant"):
                        st.write("Örneğin: Windows Security 4688 olaylarında encoded PowerShell başlatılmasını tespit et. Yönetim scriptlerini olası false positive olarak değerlendir.")
                _render_messages(st, root, owner, messages)
                live_message = st.empty()
            readonly = user.get("role") not in {"L1", "L2", "L3", "admin"}
            text = st.chat_input("Senaryonu yaz, kodu yapıştır veya son taslağı revize et…", key="ds_chat_input", max_chars=16000, disabled=readonly)
            if readonly:
                st.caption("Bu hesap geçmişi okuyabilir. Üretim için L1/L2/L3/admin rolü gerekir.")
            else:
                st.caption("Kod yalnız statik incelenir · AQL canlı çalıştırılmaz · Sonraki mesajın açık taslağı revize eder")
        if text:
            try:
                authorize()
                if not st.session_state.get("ds_chat_active"):
                    st.session_state["ds_chat_active"] = chat.new_chat(root, owner, text[:90])
                with live_message.container():
                    with st.chat_message("user"):
                        st.markdown(text)
                    st.caption("Mesajın işleniyor; aşamaları sağ panelden izleyebilirsin.")
                chat.process(root, owner, st.session_state["ds_chat_active"], text, authorize,
                             on_progress=lambda rows: panel.markdown(flow_html(rows), unsafe_allow_html=True))
                st.rerun()
            except core.StudioError as exc:
                st.error(str(exc))
            except Exception:
                st.error("Sohbet işlenemedi. Studio dizini izinlerini ve bağlantı ayarlarını kontrol edin.")
