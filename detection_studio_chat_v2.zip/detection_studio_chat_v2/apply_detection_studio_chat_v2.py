#!/usr/bin/env python3
"""Dry-run/apply/verify a minimal patch against the user's current dashboard."""
import argparse
import ast
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile

MARKER = "# DETECTION_STUDIO_PHASE2_V1_ROUTE_BEGIN"


def patch_dashboard(text, project_root=None):
    root_line = ('        Path(' + repr(str(project_root)) + '),\n'
                 if project_root is not None else '        Path(__file__).resolve().parent,\n')
    if MARKER in text:
        expected = [
            '_PERSISTENT_DA_PAGES = {"HEALTH", "ACTIVITY", "OFFENSE_VOLUME", "MITRE", "STUDIO"}',
            '            "STUDIO": "🧪 Detection Studio",',
            "            ['HEALTH', 'ACTIVITY', 'OFFENSE_VOLUME', 'MITRE', 'STUDIO'],",
            'if page == "🧪 Detection Studio":',
            '    from detection_studio_ui import render_detection_studio',
            '        current_user=_platform_current_db_user,',
        ]
        if text.count(MARKER) != 1 or any(item not in text for item in expected):
            raise ValueError("Incomplete existing Detection Studio patch")
        if project_root is not None:
            start = text.index(MARKER)
            end = text.index('# DETECTION_STUDIO_PHASE2_V1_ROUTE_END', start)
            block = text[start:end]
            old_line = '        Path(__file__).resolve().parent,\n'
            if old_line in block:
                block = block.replace(old_line, root_line, 1)
            elif root_line not in block:
                raise ValueError("Existing Studio route points to a different project root")
            text = text[:start] + block + text[end:]
        ast.parse(text)
        return text
    replacements = [
        ('_PERSISTENT_DA_PAGES = {"HEALTH", "ACTIVITY", "OFFENSE_VOLUME", "MITRE"}',
         '_PERSISTENT_DA_PAGES = {"HEALTH", "ACTIVITY", "OFFENSE_VOLUME", "MITRE", "STUDIO"}'),
        ('        _da_page_labels = {\n', '        _da_page_labels = {\n            "STUDIO": "🧪 Detection Studio",\n'),
        ("            ['HEALTH', 'ACTIVITY', 'OFFENSE_VOLUME', 'MITRE'],",
         "            ['HEALTH', 'ACTIVITY', 'OFFENSE_VOLUME', 'MITRE', 'STUDIO'],"),
        ('        page = {\n            "MITRE": "🧭 MITRE",',
         '        page = {\n            "STUDIO": "🧪 Detection Studio",\n            "MITRE": "🧭 MITRE",'),
        ('# DETECTION_HEALTH_TAB_V1_ROUTE_BEGIN',
         MARKER + '\nif page == "🧪 Detection Studio":\n'
         '    _platform_require_assigned_role()\n'
         '    from detection_studio_ui import render_detection_studio\n'
         '    render_detection_studio(\n'
         + root_line +
         '        require_role=_platform_require_assigned_role,\n'
         '        current_user=_platform_current_db_user,\n'
         '    )\n'
         '    st.stop()\n'
         '# DETECTION_STUDIO_PHASE2_V1_ROUTE_END\n\n\n'
         '# DETECTION_HEALTH_TAB_V1_ROUTE_BEGIN'),
    ]
    for before, after in replacements:
        count = text.count(before)
        if count != 1:
            raise ValueError("Dashboard anchor is missing or ambiguous: " + before[:90] + f" (count={count})")
        text = text.replace(before, after, 1)
    ast.parse(text)
    return text


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest() if path.exists() else None


def atomic_write(path, data, mode=0o644):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=".studio-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as output:
            output.write(data)
            output.flush()
            os.fsync(output.fileno())
        os.chmod(temporary, mode)
        if path.exists():
            stat = path.stat()
            try:
                os.chown(temporary, stat.st_uid, stat.st_gid)
            except PermissionError:
                pass
        os.replace(temporary, path)
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)


def payload_files(package):
    files = [p for p in sorted((package / "payload").rglob("*")) if p.is_file() and "__pycache__" not in p.parts]
    if not files:
        raise ValueError("Place this installer in detection_studio_phase2_v1 alongside its payload/ directory")
    return files


def verify(root, dashboard, package):
    text = dashboard.read_text(encoding="utf-8")
    ast.parse(text)
    if MARKER not in text:
        raise ValueError("Detection Studio dashboard route is not installed")
    if patch_dashboard(text, root) != text:
        raise ValueError("Dashboard patch is not stable")
    for source in payload_files(package):
        target = dashboard.parent / source.relative_to(package / "payload")
        if sha(source) != sha(target):
            raise ValueError("Installed payload differs: " + str(target))
    print(json.dumps({"status": "verified", "dashboard": str(dashboard),
                      "payload_files": len(payload_files(package)), "live_requests": "not_performed"}))


def restore(root, backup):
    manifest = json.loads((backup / "manifest.json").read_text(encoding="utf-8"))
    if Path(manifest["root"]).resolve() != root:
        raise ValueError("Backup belongs to another installation root")
    # Check *all* files before restoring any, to avoid overwriting later work.
    for row in manifest["files"]:
        path = Path(row["path"])
        if sha(path) != row["installed_sha256"]:
            raise ValueError("A file changed after install; rollback aborted: " + str(path))
    for row in reversed(manifest["files"]):
        path = Path(row["path"])
        if row["backup"] is None:
            path.unlink()
        else:
            original = backup / row["backup"]
            atomic_write(path, original.read_bytes(), row["mode"])
    print(json.dumps({"status": "rolled_back", "backup": str(backup)}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=Path("/data/tomsoc_rag"))
    parser.add_argument("--dry-run", action="store_true", help="Plan only (also the default)")
    parser.add_argument("--dashboard", type=Path, help="Auto-detect ROOT/dashboard/dashboard.py or ROOT/dashboard.py")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--apply", action="store_true")
    mode.add_argument("--verify", action="store_true")
    mode.add_argument("--rollback", type=Path, help="Path printed by apply")
    args = parser.parse_args()
    if args.dry_run and (args.apply or args.verify or args.rollback):
        parser.error("--dry-run cannot be combined with apply/verify/rollback")
    root = args.root.resolve()
    package = Path(__file__).resolve().parent
    try:
        if args.rollback:
            restore(root, args.rollback.resolve())
            return
        if args.dashboard:
            dashboard = args.dashboard.resolve()
        else:
            candidates = [p for p in (root / "dashboard/dashboard.py", root / "dashboard.py") if p.is_file()]
            if len(candidates) != 1:
                raise ValueError("Dashboard missing or ambiguous. Pass --dashboard /full/path/dashboard.py")
            dashboard = candidates[0].resolve()
        if dashboard.is_symlink():
            raise ValueError("Dashboard symlink is not supported")
        if not dashboard.is_relative_to(root):
            raise ValueError("Dashboard must be inside --root")
        if args.verify:
            verify(root, dashboard, package)
            return
        original = dashboard.read_text(encoding="utf-8")
        patched = patch_dashboard(original, root)
        changes = [(source, dashboard.parent / source.relative_to(package / "payload")) for source in payload_files(package)]
        planned = [(target, source.read_bytes()) for source, target in changes]
        planned.append((dashboard, patched.encode("utf-8")))
        for target, data in planned:
            if target.suffix == ".py":
                ast.parse(data.decode("utf-8"))
        baseline = json.loads((package / "BASELINE_HASHES.json").read_text(encoding="utf-8"))
        for source, target in changes:
            relative = source.relative_to(package / "payload").as_posix()
            if target.is_symlink() or any(p.is_symlink() for p in target.parents if p != root.parent):
                raise ValueError("Symlink target is not supported: " + str(target))
            if target.exists() and sha(target) not in {sha(source), baseline.get(relative)}:
                raise ValueError("Existing Studio module differs from the reviewed version; no files written: " + str(target))
        changed = [(target, data) for target, data in planned if not target.exists() or target.read_bytes() != data]
        if not args.apply:
            print(json.dumps({"status": "dry_run_ok", "changed_files": [str(p) for p, _ in changed],
                              "dashboard_patch": "existing_studio_route_or_minimal_5_anchors", "qa_changes": False}, indent=2))
            return
        if not changed:
            print('{"status":"already_installed"}')
            return
        tag = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
        backup = root / "backups" / ("detection-studio-chat-v2-" + tag)
        backup.mkdir(parents=True, mode=0o700)
        records = []
        for index, (target, data) in enumerate(changed):
            existed = target.exists()
            name = f"{index:03d}.bak" if existed else None
            file_mode = target.stat().st_mode & 0o777 if existed else 0o644
            if existed:
                shutil.copy2(target, backup / name)
            records.append({"path": str(target), "backup": name, "mode": file_mode,
                            "before_sha256": sha(target), "installed_sha256": hashlib.sha256(data).hexdigest()})
        manifest = {"root": str(root), "files": records}
        atomic_write(backup / "manifest.json", json.dumps(manifest, indent=2).encode(), 0o600)
        applied = []
        try:
            for (target, data), row in zip(changed, records):
                atomic_write(target, data, row["mode"])
                applied.append(row)
        except Exception:
            for row in reversed(applied):
                if row["backup"]:
                    atomic_write(Path(row["path"]), (backup / row["backup"]).read_bytes(), row["mode"])
                else:
                    Path(row["path"]).unlink()
            raise
        print(json.dumps({"status": "applied", "backup": str(backup), "changed_files": len(changed)}, indent=2))
        verify(root, dashboard, package)
    except (OSError, ValueError, KeyError) as exc:
        raise SystemExit("[ERROR] " + str(exc))


if __name__ == "__main__":
    main()
