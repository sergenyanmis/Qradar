"""Offline regression tests; no QRadar/Heimdall calls or production files."""
import copy
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import sys
import subprocess
import tempfile
import unittest
from unittest.mock import patch

PACKAGE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PACKAGE / "payload"))
from detection_studio_runtime import core

spec = importlib.util.spec_from_file_location("studio_installer", PACKAGE / "apply_detection_studio_chat_v2.py")
installer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(installer)

SIGMA = """title: Encoded PowerShell Test
id: e10d5415-20b1-4c24-ac5f-4fda8b20c001
status: experimental
description: Test process command line behavior
author: Detection Studio Test
logsource:
  product: windows
  category: process_creation
detection:
  selection:
    CommandLine|contains: ' -enc '
  condition: selection
falsepositives:
  - Administrative scripts
level: medium
"""


def fixture_environment(root):
    fields = ["starttime", "logsourceid", "qid", "username", "sourceip", "destinationip", "payload", "Event ID", "Command", "Status", "Stage"]
    sources = [{"id": sid, "name": str(sid), "enabled": True} for sid in (18127, 2380, 19445)]
    catalog = {"datasets": {"event_fields": {"items": [{"name": n, "object_value_type": "String"} for n in fields]},
                            "log_sources": {"items": sources}}}
    raw = json.dumps(catalog).encode()
    profile = {"catalog_sha256": hashlib.sha256(raw).hexdigest(), "windows_observations": [
        {"profile": "windows_process", "log_source_id": 18127, "fields": {"Event ID": {"populated_rows": 50}, "Command": {"populated_rows": 26}}}],
        "paloalto_globalprotect": {"validated_sample_mappings": [
            {"role": "client_public_ip", "aql_field": "sourceip", "log_source_id": sid,
             "equal_rows": 50, "conditions": {"cat": "GLOBALPROTECT"}} for sid in (2380, 19445)],
             "identity_state": "unresolved_normalization_or_mapping", "constraints": ["Failure status not raw-validated."]}}
    folder = Path(root) / "detection_studio"
    (folder / "catalog").mkdir(parents=True)
    (folder / "catalog/catalog.json").write_bytes(raw)
    (folder / "environment_profile.json").write_text(json.dumps(profile))
    return core.load_environment(root)


def draft():
    data = copy.deepcopy(core.CONTRACT)
    data.update(title="Encoded PowerShell", sigma_yaml=SIGMA,
                aql_where='"Event ID" = \'4688\' AND ("Command" ILIKE \'% -enc %\')',
                projection_fields=["starttime", "qid", "Command"],
                field_mappings=[{"sigma_field": "CommandLine", "aql_field": "Command", "reason": "Population observed; semantics pending."}])
    return data


def dashboard_fixture(path):
    """Normalize only our known route inside a test copy, never mutate the input."""
    source = Path(path).read_text(encoding="utf-8")
    if installer.MARKER in source:
        start = source.index(installer.MARKER)
        marker_end = '# DETECTION_STUDIO_PHASE2_V1_ROUTE_END'
        end = source.index(marker_end, start) + len(marker_end)
        source = source[:start] + source[end:]
        source = source.replace(', "STUDIO"}', '}')
        source = source.replace(", 'STUDIO'],", "],")
        source = source.replace('            "STUDIO": "🧪 Detection Studio",\n', '')
    return source


class CoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.env = fixture_environment(self.root)
        self.context = core.grounding(self.env, "windows_process", [18127])

    def tearDown(self):
        self.temp.cleanup()

    def test_catalog_hash_mismatch_is_rejected(self):
        p = self.root / "detection_studio/catalog/catalog.json"
        p.write_bytes(p.read_bytes() + b" ")
        with self.assertRaises(core.StudioError):
            core.load_environment(self.root)

    def test_other_source_cannot_be_selected(self):
        with self.assertRaises(core.StudioError):
            core.grounding(self.env, "windows_process", [2380])

    def test_scope_and_provider_survive_broad_filter(self):
        d = draft()
        d["aql_where"] = "1 = 1 OR 2 = 2"
        query, _ = core.compile_aql(d, self.context)
        self.assertIn("(logsourceid IN (18127)) AND", query)
        self.assertIn("Microsoft-Windows-Security-Auditing", query)
        self.assertIn("AND (1 = 1 OR 2 = 2)", query)
        self.assertTrue(query.endswith("LIMIT 100 LAST 60 MINUTES"))

    def test_field_checks_block_unknown_and_query_clauses(self):
        for predicate in ['"Invented Field" = 1', "SELECT * FROM events", "1=1; SELECT 1", "1=1 -- comment", "evil(payload) = 1", "(qid = 1", "qid = 'broken"]:
            with self.subTest(predicate=predicate), self.assertRaises(core.StudioError):
                core.predicate_fields(predicate, self.context["fields"])

    def test_literals_and_keyword_parentheses(self):
        used = core.predicate_fields('NOT (qid IN (1,2)) OR ("Command" ILIKE \'%SELECT%\')', self.context["fields"])
        self.assertEqual(used, {"qid", "Command"})

    def test_bad_projection_and_aggregation_rejected(self):
        d = draft()
        d["projection_fields"] = ["not_catalogued"]
        with self.assertRaises(core.StudioError):
            core.compile_aql(d, self.context)
        d = draft()
        d["aggregation"] = {"group_by": ["username"], "record_count_min": 5}
        query, _ = core.compile_aql(d, self.context)
        self.assertIn("GROUP BY username HAVING COUNT(*) >= 5", query)

    def test_semantics_not_promoted_to_verified(self):
        audit = core.audit_draft(draft(), self.context)
        self.assertIn(audit["sigma"]["status"], {"pysigma_parsed", "yaml_checked_pysigma_missing"})
        command = next(x for x in audit["field_evidence"] if x["field"] == "Command")
        self.assertEqual(command["evidence"], "population_only")
        self.assertEqual(audit["aql_syntax"], "not_tested_on_qradar")
        self.assertEqual(audit["live_search"], "not_run")
        self.assertEqual(audit["sigma_aql_equivalence"], "not_verified")

    def test_vpn_mapping_stays_scoped(self):
        context = core.grounding(self.env, "paloalto_globalprotect", [2380])
        self.assertTrue(all(row["log_source_id"] == 2380 for row in context["same_row_sample_mappings"]))
        self.assertNotIn("username", {row["aql_field"] for row in context["same_row_sample_mappings"]})
        self.assertIn("|cat=GLOBALPROTECT|", context["mandatory_scope_predicate"])

    def test_sigma_duplicate_keys_and_missing_mapping(self):
        self.assertEqual(core.validate_sigma(SIGMA + "title: repeated\n")["status"], "invalid")
        d = draft()
        d["field_mappings"] = []
        self.assertEqual(core.audit_draft(d, self.context)["state"], "blocked")

    def test_invalid_contract_and_truncation(self):
        for reason in ("length", "content_filter", None):
            with self.assertRaises(core.StudioError):
                core.parse_completion({"choices": [{"finish_reason": reason, "message": {"content": json.dumps(draft())}}]})
        d = draft()
        d["lookback_minutes"] = True
        with self.assertRaises(core.StudioError):
            core.validate_contract(d)

    def test_model_request_is_fixed_and_code_is_only_data(self):
        captured = []
        def opener(req, timeout):
            captured.append((req, timeout))
            return io.BytesIO(json.dumps({"choices": [{"finish_reason": "stop", "message": {"content": json.dumps(draft())}}]}).encode())
        supplied_code = "import os; os.system('touch SHOULD_NOT_EXIST')"
        with patch.dict(os.environ, {"HEIMDALL_TOKEN": "unit-test-token"}):
            result, metadata = core.request_draft(self.root, self.context, supplied_code, "code", opener=opener)
        body = json.loads(captured[0][0].data)
        self.assertEqual(body["model"], core.MODEL)
        self.assertFalse(body["chat_template_kwargs"]["enable_thinking"])
        self.assertEqual(json.loads(body["messages"][1]["content"])["input"], supplied_code)
        self.assertEqual(metadata["model"], core.MODEL)
        self.assertFalse(Path("SHOULD_NOT_EXIST").exists())

    def test_private_history_revisions_and_owner_isolation(self):
        data = draft()
        audit = core.audit_draft(data, self.context)
        meta = {"model": core.MODEL}
        first = core.save_draft(self.root, "alice", "scenario text", "scenario", self.context, data, audit, meta)
        second = core.save_draft(self.root, "alice", "scenario text", "scenario", self.context, data, audit, meta, first["id"])
        self.assertEqual(second["revision"], 2)
        self.assertEqual(first["input_sha256"], second["input_sha256"])
        self.assertIsNone(core.get_draft(self.root, "bob", first["id"]))
        self.assertEqual(core.list_drafts(self.root, "bob"), [])
        with self.assertRaises(core.StudioError):
            core.save_draft(self.root, "bob", "scenario text", "scenario", self.context, data, audit, meta, first["id"])
        self.assertEqual((self.root / "detection_studio/drafts/studio.sqlite3").stat().st_mode & 0o777, 0o600)


class InstallerTests(unittest.TestCase):
    def test_actual_dashboard_patch_compiles_and_is_idempotent(self):
        path = os.getenv("STUDIO_TEST_DASHBOARD")
        if not path:
            self.skipTest("Set STUDIO_TEST_DASHBOARD to test the current source")
        source = dashboard_fixture(path)
        patched = installer.patch_dashboard(source)
        self.assertEqual(installer.patch_dashboard(patched), patched)
        self.assertEqual(patched.count(installer.MARKER), 1)
        self.assertIn('current_user=_platform_current_db_user', patched)
        compile(patched, "dashboard.py", "exec")
        with self.assertRaises(ValueError):
            installer.patch_dashboard(source.replace("_PERSISTENT_DA_PAGES =", "_RENAMED_DA_PAGES ="))

    def test_apply_verify_idempotence_and_rollback(self):
        path = os.getenv("STUDIO_TEST_DASHBOARD")
        if not path:
            self.skipTest("Set STUDIO_TEST_DASHBOARD to test the current source")
        source = dashboard_fixture(path).encode("utf-8")
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            dashboard = root / "dashboard.py"
            dashboard.write_bytes(source)
            command = [sys.executable, str(PACKAGE / "apply_detection_studio_chat_v2.py"), "--root", str(root)]
            dry = subprocess.run(command, capture_output=True, text=True, check=True)
            self.assertIn("dry_run_ok", dry.stdout)
            self.assertEqual(source, dashboard.read_bytes())
            subprocess.run(command + ["--apply"], capture_output=True, text=True, check=True)
            subprocess.run(command + ["--verify"], capture_output=True, text=True, check=True)
            again = subprocess.run(command + ["--apply"], capture_output=True, text=True, check=True)
            self.assertIn("already_installed", again.stdout)
            backup = next((root / "backups").iterdir())
            subprocess.run(command + ["--rollback", str(backup)], capture_output=True, text=True, check=True)
            self.assertEqual(source, dashboard.read_bytes())
            self.assertFalse((root / "detection_studio_ui.py").exists())


if __name__ == "__main__":
    unittest.main(verbosity=2)
