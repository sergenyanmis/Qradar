import copy
import importlib.util
import io
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from test_studio import PACKAGE, core, draft, fixture_environment, installer, dashboard_fixture
from detection_studio_runtime import chat


def plan():
    return {"action": "generate", "profile": "windows_process", "source_ids": [18127], "extra_fields": [],
            "reason": "Process creation görünürlüğü olan gözlenen kaynak seçildi.", "clarification": ""}


class ChatTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.env = fixture_environment(self.root)
        self.cid = chat.new_chat(self.root, "alice")
        self.p1 = patch.object(chat, "request_plan", return_value=(plan(), {"model": core.MODEL}))
        self.p2 = patch.object(core, "request_draft", return_value=(draft(), {"model": core.MODEL}))
        self.planner = self.p1.start()
        self.engineer = self.p2.start()
        self.events = []

    def tearDown(self):
        self.p2.stop()
        self.p1.stop()
        self.temp.cleanup()

    def run_turn(self, text="PowerShell encoded command başlatılmasını tespit et", authorize=lambda: None):
        return chat.process(self.root, "alice", self.cid, text, authorize, self.events.append)

    def test_automatic_selection_scope_and_true_stage_order(self):
        result = self.run_turn()
        self.assertEqual(result["status"], "saved")
        record = result["record"]
        self.assertIn("logsourceid IN (18127)", record["validation"]["aql"])
        self.assertIn("Microsoft-Windows-Security-Auditing", record["validation"]["aql"])
        self.assertEqual(record["validation"]["live_search"], "not_run")
        running = [next(e["id"] for e in rows if e["state"] == "running") for rows in self.events if any(e["state"] == "running" for e in rows)]
        self.assertEqual(running, [key for key, _, _ in chat.STAGES])
        _, messages = chat.read_chat(self.root, "alice", self.cid)
        self.assertEqual([m["role"] for m in messages], ["user", "assistant"])
        self.assertEqual(messages[-1]["metadata"]["events"][-1]["state"], "complete")

    def test_revision_uses_previous_draft_and_new_instruction(self):
        first = self.run_turn()["record"]
        second = self.run_turn("Pencereyi 30 dakikaya indir")["record"]
        self.assertEqual(second["parent_id"], first["id"])
        self.assertEqual(second["revision"], 2)
        args = self.engineer.call_args.args
        self.assertEqual(args[4], first["draft"])
        self.assertIn("30 dakikaya", args[5])
        self.assertEqual(len(chat.read_chat(self.root, "alice", self.cid)[1]), 4)

    def test_clarification_creates_no_draft_and_next_answer_keeps_context(self):
        self.planner.return_value = ({"action": "clarify", "profile": "", "source_ids": [], "extra_fields": [],
                                     "reason": "Telemetri belirsiz", "clarification": "Windows Security mi Sysmon mu hedefliyorsun?"}, {})
        result = self.run_turn("Şüpheli process tespit et")
        self.assertEqual(result["status"], "clarification")
        self.engineer.assert_not_called()
        self.assertEqual(core.list_drafts(self.root, "alice"), [])
        self.assertTrue(all(e["state"] == "skipped" for e in result["events"][3:]))
        self.planner.return_value = (plan(), {})
        self.assertEqual(self.run_turn("Windows Security 4688 üzerinden")["status"], "saved")
        self.assertIn("Şüpheli process", self.engineer.call_args.args[2])

    def test_catalog_invalid_selection_and_disabled_source_are_blocked(self):
        for updates in ({"source_ids": [2380]}, {"source_ids": [True]}, {"source_ids": [18127, 18127]},
                        {"source_ids": [99999]}, {"extra_fields": ["Invented Field"]}, {"profile": "linux"}):
            candidate = {**plan(), **updates}
            with self.subTest(updates=updates), self.assertRaises(core.StudioError):
                chat.validate_plan(candidate, self.env)
        self.env["sources"][18127]["enabled"] = False
        with self.assertRaises(core.StudioError):
            chat.validate_plan(plan(), self.env)

    def test_blocked_draft_saved_and_no_live_success_claimed(self):
        data = draft()
        data["aql_where"] = '"Unknown" = 1'
        self.engineer.return_value = (data, {"model": core.MODEL})
        result = self.run_turn()
        self.assertEqual(result["status"], "saved")
        self.assertEqual(result["record"]["validation"]["state"], "blocked")
        self.assertEqual(result["events"][4]["state"], "needs_revision")

    def test_failure_marks_active_stage_and_skips_rest(self):
        self.engineer.side_effect = core.StudioError("Heimdall HTTP 503. Taslak kaydedilmedi.")
        result = self.run_turn()
        self.assertEqual(result["status"], "error")
        self.assertEqual(result["events"][3]["state"], "error")
        self.assertEqual(result["events"][4]["state"], "skipped")
        self.assertEqual(core.list_drafts(self.root, "alice"), [])
        self.assertIsNone(chat.read_chat(self.root, "alice", self.cid)[0]["last_draft_id"])

    def test_chat_and_import_owner_isolation(self):
        record = self.run_turn()["record"]
        self.assertEqual(chat.list_chats(self.root, "bob"), [])
        for function, args in ((chat.read_chat, (self.cid,)), (chat.import_draft, (record["id"],))):
            with self.assertRaises(core.StudioError):
                function(self.root, "bob", *args)
        cid = chat.import_draft(self.root, "alice", record["id"])
        self.assertEqual(chat.read_chat(self.root, "alice", cid)[0]["last_draft_id"], record["id"])

    def test_role_revocation_before_save_prevents_draft(self):
        calls = []
        def authorize():
            calls.append(True)
            if len(calls) >= 4:
                raise core.StudioError("Üretim yetkisi doğrulanamadı.")
        result = self.run_turn(authorize=authorize)
        self.assertEqual(result["status"], "error")
        self.assertEqual(core.list_drafts(self.root, "alice"), [])

    def test_draft_and_chat_insert_are_atomic(self):
        def fail(*args):
            raise RuntimeError("test callback failure")
        context = core.grounding(self.env, "windows_process", [18127])
        with self.assertRaises(RuntimeError):
            core.save_draft(self.root, "alice", "test scenario", "scenario", context, draft(),
                            core.audit_draft(draft(), context), {"model": core.MODEL}, after_insert=fail)
        self.assertEqual(core.list_drafts(self.root, "alice"), [])

    def test_snapshot_change_blocks_before_planner(self):
        p = self.root / "detection_studio/catalog/catalog.json"
        p.write_bytes(p.read_bytes() + b" ")
        self.assertEqual(self.run_turn()["status"], "error")
        self.planner.assert_not_called()


class TransportTests(unittest.TestCase):
    def test_planner_request_is_bounded_and_grounded(self):
        with tempfile.TemporaryDirectory() as folder:
            env = fixture_environment(folder)
            captured = []
            def opener(req, timeout):
                captured.append((req, timeout))
                return io.BytesIO(json.dumps({"choices": [{"finish_reason": "stop", "message": {"content": json.dumps(plan())}}]}).encode())
            with patch.dict(os.environ, {"HEIMDALL_TOKEN": "synthetic-test"}):
                selected, _ = chat.request_plan(folder, env, [{"role": "user", "content": "encoded PowerShell"}], opener=opener)
            body = json.loads(captured[0][0].data)
            self.assertEqual(body["max_tokens"], 2000)
            self.assertEqual(body["model"], core.MODEL)
            self.assertFalse(body["stream"])
            payload = json.loads(body["messages"][1]["content"])
            self.assertIn("Command", payload["environment"]["catalog_fields"])
            self.assertEqual(chat.validate_plan(selected, env)["selected_sources"][0]["id"], 18127)


class NewInstallerTests(unittest.TestCase):
    def test_nested_upgrade_preserves_data_and_modified_module_aborts(self):
        path = os.getenv("STUDIO_TEST_DASHBOARD")
        if not path:
            self.skipTest("STUDIO_TEST_DASHBOARD required")
        source = dashboard_fixture(path)
        baseline = Path(os.environ["STUDIO_BASELINE_PAYLOAD"]) if os.getenv("STUDIO_BASELINE_PAYLOAD") else None
        with tempfile.TemporaryDirectory() as folder:
            root = Path(folder)
            dashboard = root / "dashboard/dashboard.py"
            dashboard.parent.mkdir()
            dashboard.write_text(installer.patch_dashboard(source))
            if baseline:
                import shutil
                shutil.copytree(baseline, dashboard.parent, dirs_exist_ok=True)
            command = [sys.executable, str(PACKAGE / "apply_detection_studio_chat_v2.py"), "--root", str(root)]
            untouched = root / "detection_studio/drafts/studio.sqlite3"
            untouched.parent.mkdir(parents=True)
            untouched.write_bytes(b"sentinel-data")
            dry = subprocess.run(command + ["--dry-run"], capture_output=True, text=True, check=True)
            self.assertIn("dry_run_ok", dry.stdout)
            subprocess.run(command + ["--apply"], capture_output=True, text=True, check=True)
            self.assertIn(repr(str(root)), dashboard.read_text())
            subprocess.run(command + ["--verify"], capture_output=True, text=True, check=True)
            self.assertEqual(untouched.read_bytes(), b"sentinel-data")
            target = dashboard.parent / "detection_studio_ui.py"
            target.write_text(target.read_text() + "\n# later customization\n")
            failed = subprocess.run(command + ["--apply"], capture_output=True, text=True)
            self.assertNotEqual(failed.returncode, 0)
            self.assertIn("no files written", failed.stderr)
            backup = next((root / "backups").iterdir())
            refused = subprocess.run(command + ["--rollback", str(backup)], capture_output=True, text=True)
            self.assertNotEqual(refused.returncode, 0)
            self.assertIn("rollback aborted", refused.stderr)


class UITests(unittest.TestCase):
    def setUp(self):
        original_draft, original_plan = core.request_draft, chat.request_plan
        self.addCleanup(setattr, core, "request_draft", original_draft)
        self.addCleanup(setattr, chat, "request_plan", original_plan)

    def test_chat_generate_revise_new_and_reopen(self):
        from streamlit.testing.v1 import AppTest
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {"STUDIO_UI_TEST_ROOT": folder}):
            app = AppTest.from_file(str(PACKAGE / "tests/ui_smoke_app.py"), default_timeout=30).run()
            self.assertFalse(app.exception)
            self.assertFalse(any(x.label == "Telemetri profili" for x in app.selectbox))
            app.chat_input[0].set_value("Windows Security 4688 encoded PowerShell tespiti yap").run()
            self.assertFalse(app.exception)
            self.assertEqual(core.list_drafts(folder, "unit-user")[0]["revision"], 1)
            app.chat_input[0].set_value("Pencereyi 30 dakika yap").run()
            self.assertFalse(app.exception)
            self.assertEqual(core.list_drafts(folder, "unit-user")[0]["revision"], 2)
            self.assertEqual(len(app.chat_message), 4)
            app.button(key="ds_new_chat").click().run()
            self.assertFalse(app.exception)
            self.assertNotIn("ds_chat_active", app.session_state)
            app.button(key="ds_open_chat").click().run()
            self.assertFalse(app.exception)
            self.assertEqual(len(app.chat_message), 4)

    def test_readonly_and_user_switch(self):
        from streamlit.testing.v1 import AppTest
        with tempfile.TemporaryDirectory() as folder, patch.dict(os.environ, {"STUDIO_UI_TEST_ROOT": folder}):
            app = AppTest.from_file(str(PACKAGE / "tests/ui_smoke_app.py"), default_timeout=30).run()
            app.chat_input[0].set_value("Windows Security encoded PowerShell tespiti").run()
            with patch.dict(os.environ, {"STUDIO_UI_TEST_USER": "bob", "STUDIO_UI_TEST_ROLE": "readonly"}):
                app.run()
                self.assertFalse(app.exception)
                self.assertTrue(app.chat_input[0].disabled)
                self.assertNotIn("ds_chat_active", app.session_state)
                self.assertEqual(chat.list_chats(folder, "bob"), [])


if __name__ == "__main__":
    unittest.main(verbosity=2)
