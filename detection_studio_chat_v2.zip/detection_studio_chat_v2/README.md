# Detection Studio — Sohbet v2

Bu paket, 20 Ekim 2026'da paylaşılan `dashboard(1).txt` Python kaynağı ve
`detection_studio_phase2_v1` modülleri üzerine hazırlanmıştır.

## Yeni deneyim

- Solda sohbet: senaryonu veya kodu yaz; sonraki mesajla aynı taslağı revize et.
- Profil/log source/ek alan seçim kutuları kaldırıldı. Heimdall üzerinden ortam
  planlayıcısı senaryoyu mevcut source-scoped kanıtlarla eşleştirir. Host kodu
  seçilen kaynak/alanları tekrar doğrular ve kaynak/provider filtresini AQL'ye ekler.
- Sağda gerçek aşamalar: katalog → ortam planlayıcısı → kapsam kontrolü → Detection
  Engineer → taslak kontrolleri → sürüm kaydı. Bir işlem başlamadan çalışıyor denmez.
- Sigma/AQL ve alan kanıtları asistan mesajı içinde sekmelerde görünür.
- Sohbetler kalıcıdır; eski taslaklar "Taslakla sohbet başlat" ile açılabilir.
- Belirsiz davranış veya uygun telemetri yoksa sohbetten açıklama istenir.
- Başarısız istek, tamamlanmamış aşamaları başarılı göstermez. Doğrulama hatalı taslak
  açıkça düzeltme gerektiriyor olarak saklanır; sohbette revize edilebilir.

## Kurulum

Sunucudaki mevcut sanal ortamı kullanın. ZIP'i `/data/tomsoc_rag` altına koyup:

```bash
cd /data/tomsoc_rag
unzip detection_studio_chat_v2.zip
cd detection_studio_chat_v2
python3 apply_detection_studio_chat_v2.py --root /data/tomsoc_rag --dry-run
python3 apply_detection_studio_chat_v2.py --root /data/tomsoc_rag --apply
python3 apply_detection_studio_chat_v2.py --root /data/tomsoc_rag --verify
```

Ardından dashboard servisini mevcut yönteminizle yeniden başlatın. Servis adı
varsayılmadı. Python'ın import ettiği eski runtime'ın yenilenmesi için restart gereklidir.

Installer `ROOT/dashboard/dashboard.py` veya `ROOT/dashboard.py` dosyasını otomatik
bulur. İkisi de varsa açıkça hedef belirtin (aynı argümanı üç komuta da ekleyin):

```bash
--dashboard /data/tomsoc_rag/dashboard/dashboard.py
```

Gönderilen dashboard snapshot'ında Studio route'u bulunmuyor. Installer gerekli
beş bağlantı noktasına minimal değişiklik yapar; route zaten mevcutsa tekrar eklemez.
Nested dashboard'da UI/runtime o dizine kurulur, veri kökü `/data/tomsoc_rag` kalır.

Mevcut modüller orijinal Faz 2'den veya bu paketten farklıysa installer **hiçbir
dosyayı yazmadan durur**. Böylece sonraki özelleştirmeler körlemesine ezilmez.
`Existing Studio module differs...` hatasında ilgili güncel modül incelenerek patch
uyarlanmalıdır; dosyayı silerek veya kontrolü kaldırarak geçmeyin.

### Bağımlılıklar

Yeni runtime ek Python paketi gerektirmez; mevcut Faz 2 ortamı kullanılır:
Python 3.10+ (test edilen 3.12), Streamlit 1.41+ (test edilen 1.66.0), PyYAML,
pySigma. Mevcut sürümü görmek için `python3 -m pip show streamlit` kullanılabilir.
Streamlit yeterliyse yeniden kurmaya gerek yoktur. Sigma bağımlılıkları eksikse:

```bash
python3 -m pip install -r requirements.txt
```

Streamlit sürümü 1.41'den düşükse mevcut platform bağımlılıklarıyla uyumlu bir
sürüme yükseltilmelidir. Installer bağımlılık veya servis ayarlarını değiştirmez.

## Ortam ve kapsam

Önceki fazdan şu iki dosya bulunmalıdır:

```text
/data/tomsoc_rag/detection_studio/catalog/catalog.json
/data/tomsoc_rag/detection_studio/environment_profile.json
```

Profil ve katalog aynı SHA-256 snapshot'ını kullanmalıdır. Profil yoksa önceki
probe sonuçları mevcutken `python3 build_detection_studio_profile_v1.py --root
/data/tomsoc_rag` çalıştırılır; bu builder bu paketin parçası değildir.

Desteklenen profiller değişmedi:

1. Windows Security / kimlik doğrulama.
2. Windows Security / process creation.
3. Windows Sysmon.
4. Palo Alto GlobalProtect.

Otomatik planlayıcı bu profillerde **ortam profilinde gözlenmiş**, katalogda mevcut
ve enabled kaynaklardan 1–8 tanesini seçebilir. Katalogdaki 4452 kaynağın tamamında
alan semantiği doğrulanmış gibi davranmaz. Gerektiğinde katalogdan 20 ek alan
otomatik seçilebilir; bunlar yalnız `catalog_only` kanıtındadır. Linux/FortiGate
gibi desteklenmeyen profil veya farklı profiller arasında korelasyon bu sürümde
otomatik destekleniyor sayılmaz; açıklama/telemetri eksikliği olarak döner.

## Heimdall

Mevcut ayarlar aynen kullanılır:

- Token: ortam `HEIMDALL_TOKEN`, yoksa kökteki `qradar_secrets.py`.
- Endpoint: `https://heimdall-uat.tombank.com.tr/v1/chat/completions`.
- Override: `SOC_DETECTION_HEIMDALL_CHAT_URL`.
- Kurum CA: `SOC_DETECTION_HEIMDALL_CA_BUNDLE`.
- Model `qwen3-6-35b-a3b`, provider `vllm`, temperature 0, thinking kapalı.
- Bir üretim turu genellikle iki ardışık model çağrısı yapar: ortam planı (max 2000
  output token) ve detection taslağı (max 6000 output token). Her istek timeout'u
  180 saniyedir; toplam süre bu iki çağrının ve yerel işlemlerin toplamıdır.
- Gerçek token kullanım metrikleri toplanmaz; süreler uygulamanın ölçümüdür.

## Veriler, yetkiler ve doğruluk

`detection_studio/drafts/studio.sqlite3` korunur. İlk kullanımda mevcut `drafts`
tablosuna dokunmadan `studio_chats` ve `studio_chat_messages` tabloları eklenir.
Yeni taslak ve ona ait asistan mesajı aynı SQLite transaction'ında kaydedilir.
Sohbet erişimi ve draft import owner ile sınırlandırılır. Üretim rolü işlem
başlangıcında, model çağrılarından önce ve kayıttan önce tekrar kontrol edilir.
Readonly kullanıcı yalnız kendi mevcut sohbet/taslaklarını okuyabilir.

QA gateway, ana QA DB, skorlar ve kapanış kararları değiştirilmez. Kod çalıştırılmaz.
Katalog, environment profile ve probe sonuçları değiştirilmez.

**Bu paket canlı QRadar sorgusu çalıştırmaz veya CRE kuralı yayımlamaz.** Panelde
"Ortam kataloğu" aşaması vardır; yapılmayan sorgu/agent çağrısı gösterilmez.
Ortam planlayıcısı ve Detection Engineer aynı Heimdall modelinin iki ayrı görevidir;
özerk çoklu agent altyapısı eklendiği iddia edilmez.

AQL kontrolleri offline lexical/scope kontrolleridir; tam AQL grammar/live syntax
testi değildir. Sigma/AQL eşdeğerliği ve detection etkinliği doğrulanmaz. VPN
identity/failure semantiği ile Windows alan kanıtlarının mevcut sınırları korunur.

## Doğrulama ve geri dönüş

Paket testleri (yalnız sentetik veri, model çağrıları mock):

```bash
STUDIO_TEST_DASHBOARD=/data/tomsoc_rag/dashboard/dashboard.py \
python3 -m unittest discover -s tests -v
```

Dashboard kökteyse `STUDIO_TEST_DASHBOARD` yolunu değiştirin. Gönderilen dashboard
üzerinde fresh install ve nested Faz 2 upgrade, dry-run/apply/verify, idempotence,
rollback ve sonradan değişen modülde durma senaryoları test edildi.

Apply çıktısı yedek dizinini verir. Geri almak için gerçek yedek yolunu kullanın:

```bash
python3 apply_detection_studio_chat_v2.py --root /data/tomsoc_rag \
  --rollback /data/tomsoc_rag/backups/detection-studio-chat-v2-GERCEK_ZAMAN
```

Sonradan değişen kurulu dosya varsa hash kontrolü rollback'i durdurur. Katalog,
taslaklar ve sohbet tabloları silinmez. Önceki UI sohbet tablolarını kullanmaz;
mevcut eski taslakları okumaya devam eder. Geri dönüş sonrası da servis restart gerekir.

`VALIDATION.json` gerçek test kapsamını ve canlı test sınırlarını içerir.
`dashboard_changes.diff` yalnız dashboard üzerindeki değişiklikleri gösterir.
